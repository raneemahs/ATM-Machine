/******************************************************************************
 *
 * Module: Card module
 *
 * File Name: Card.h
 *
 * Description: This card module take gets the card informations
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/

#ifndef CARD_H_
#define CARD_H_

#include "std_types.h"
#define _CRT_SECURE_NO_WARNINGS
typedef struct
{

uint8 cardHolderName[25];
uint8 primaryAccountName[20];
uint8 cardExpirationDate[6];

}ST_cardData_t;

typedef enum
{
	OK,WRONG_NAME,WRONG_EXP_DATE,WRONG_PAN
}EN_cardError_t;

/*
 * Description :
 * Function responsible for getting the card holder name from the user.
 */
EN_cardError_t getCardHolderName(ST_cardData_t *cardData);

/*
 * Description :
 * Function responsible for getting the card expiry date from the user.
 */
EN_cardError_t getCardExpiryDate(ST_cardData_t *cardData);

/*
 * Description :
 * Function responsible for getting the card pan from the user.
 */
EN_cardError_t getCardPan(ST_cardData_t *cardData);

#endif /* CARD_H_ */
