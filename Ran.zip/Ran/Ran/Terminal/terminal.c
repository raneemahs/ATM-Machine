/******************************************************************************
 *
 * Module: Terminal module
 *
 * File Name: terminal.c
 *
 * Description: This card module take gets the transaction informations
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/


#include "terminal.h"
#include <stdio.h>
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS
/*
 * Description :
 * Function responsible for getting the transaction date from the user.
 */
EN_terminalError_t getTransactionDate(ST_terminalData_t *termData){

	EN_terminalError_t transactionDateState;
		uint8 day[2];//initialize a variable array of 2 elements
		uint8 DD;//initialize day
		uint8 month[2];
		uint8 MM;
		printf("Please Enter Your Transaction Date:  (DD/MM/YYYY) \n");
		scanf("%s", termData->transactionDate);
		day[0] = termData->transactionDate[0];
		day[1] = termData->transactionDate[1];
		DD = atoi(day);
		month[0] = termData->transactionDate[3];
		month[1] = termData->transactionDate[4];
		MM = atoi(month);
		if ((strlen(termData->transactionDate) != 10) || (DD>31) || (MM>12))
			{
			transactionDateState = WRONG_DATE;
			}


			else
			{
				transactionDateState = OK_;
			}
	return transactionDateState;
}

/*
 * Description :
 * Function responsible for comparing between the expiration date of the card and the transaction date.
 */
EN_terminalError_t isCardExpired(ST_cardData_t *cardData,ST_terminalData_t *termData){

	EN_terminalError_t expirationState = OK_;

	uint8 year[2];//initialize a variable array of 2 elements
	uint8 YY;
	uint8 month[2];
	uint8 MM;
	uint8 expirymonth[2];//initialize a variable array of 2 elements
	uint8 expiryMM;
	uint8 expiryyear[2];
	uint8 expiryYY;

	expirymonth[0] = cardData->cardExpirationDate[0];
	expirymonth[1] = cardData->cardExpirationDate[1];
	expiryyear[0] = cardData->cardExpirationDate[3];
	expiryyear[1] = cardData->cardExpirationDate[4];
	expiryMM = atoi(expirymonth);
	expiryYY = atoi(expiryyear);
	
	year[0] = termData->transactionDate[8];
	year[1] = termData->transactionDate[9];
	YY = atoi(year);
	month[0] = termData->transactionDate[3];
	month[1] = termData->transactionDate[4];
	MM = atoi(month);

	if (expiryYY<YY)
	{
		expirationState = EXPIRED_CARD;
	}
	else if (expiryMM<MM)
	{
		expirationState = EXPIRED_CARD;
	}
	

	return expirationState;
}


/*
 * Description :
 * Function responsible for checking if the card pan is valid.
 */
EN_terminalError_t isValidCardPan(ST_cardData_t* cardData){

	EN_terminalError_t cardPanState;

	/*
	 * Luhn algorithm
	 */

	uint8 i=0,sum=0,temp;

	/*
	 *1-multiply the even index number by 2
	 *2-check if it is greater than 10 we add the number together
	 *3- add all the number together the doubled and the undoubled ones
	 */
	while(cardData->primaryAccountName[i]!='\0')
	{
		if(i%2 == 0)
		{
		temp = cardData->primaryAccountName[i]*2;
		if(temp>9)
		{
			temp = (temp / 10) + (temp % 10);
		}
		}
		else
		{
			temp = cardData->primaryAccountName[i];
		}
		sum+=temp;
		i++;
	}

	if(sum%10 != 0)
	{
		cardPanState = INVALID_CARD;
	}
	else
	{
		cardPanState = OK_;
	}
	return cardPanState;
}

/*
 * Description :
 * Function responsible for getting the transaction amount from the user.
 */
EN_terminalError_t getTransactionAmount(ST_terminalData_t *termData){

	EN_terminalError_t transactionAmountState;

	printf("Please Enter Your Transaction Amount:\n");
		scanf("%f", &termData->transAmount);
		if (termData->transAmount <= 0)
		{
			transactionAmountState = INVALID_AMOUNT;
		}
		else
		{
			transactionAmountState = OK_;
		}
	return transactionAmountState;
}

/*
 * Description :
 * Function responsible for checking if the transaction amount does not exceed the max transaction amount..
 */
EN_terminalError_t isBelowMaxAmount(ST_terminalData_t *termData){

	EN_terminalError_t transactionAmountState;
		if (termData->transAmount > termData->maxTransAmount)
		{
			transactionAmountState = EXCEED_MAX_AMOUNT;
		}
		else
		{
			transactionAmountState = OK_;
		}
		return transactionAmountState;
}

/*
 * Description :
 * Function responsible for the max transaction amount..
 */
EN_terminalError_t setMaxAmount(ST_terminalData_t *termData){

	EN_terminalError_t maxAmountState;

	termData->maxTransAmount = MAX_AMOUNT;
		if (termData->maxTransAmount <= 0)
		{
			maxAmountState = INVALID_MAX_AMOUNT;
		}
		else
		{
			maxAmountState = OK;
		}
		return maxAmountState;
}
