/******************************************************************************
 *
 * Module: server module
 *
 * File Name: server.c
 *
 * Description: This card module take gets the transaction informations and check it with the data base stored in the system
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/

#include "server.h"
#include <stdio.h>
#include <time.h>
#define _CRT_SECURE_NO_WARNINGS
ST_accountDB_t accountsDataBase[2] = { {4000,"4600919758492134602"},{500,"4848500117869590773"}};
ST_transaction_t transactionsDataBase [255];
char *stolenCards[2] = {"4600919758492134615","4848500117869590748"};
uint32 cardIndex = 0;
uint32 seqNo = 0;
float transAmounttemp;
uint8 lolo[20];

 /*
  * Description :
  * Function responsible for getting the transaction date from the user.
  */
 EN_transState_t recieveTransactionData(ST_transaction_t *transData){

 	 EN_cardError_t temp=OK;
	 EN_terminalError_t nemo;
	 EN_serverError_t stolenError;

 	 do {
 		 temp = getCardHolderName(&transData->cardHolderName);
 	 } while (temp != OK);
 	 do {
 		 temp = getCardExpiryDate(&transData->cardHolderName);

 	 } while (temp != OK);

 	 do {
 		 temp = getTransactionDate(&transData->terminalData);

 	 } while (temp != OK);
	 nemo = isAmountAvailable(&transData->terminalData);

	 stolenError = isValidAccount(&transData->cardHolderName);


 	 if (isCardExpired(&transData->cardHolderName, &transData->terminalData) == EXPIRED_CARD)
 	 {
 		 transData->transState = EXPIREDCARD;
 	 }
 	 else if (stolenError == STOLENCARD)
 	 {
 		 transData->transState = DECLINED_STOLEN_CARD;
 	 }
	 
	 else if (nemo == MaxAmountExceed)
 	 {
		 transData->transState = MaxAmouExceed;
 		 
 	 }
	 else if (nemo == LOW_BALANCE)
	 {
		 transData->transState = DECLINED_INSUFFECIENT_FUND;
	 }

 	 else if(saveTransaction(&transData) == SAVING_FAILED)
 	 {
 		 transData->transState = INTERNAL_SERVER_ERROR;
 	 }
 	 else
 	 {
 		 transData->transState = APPROVED;
 	 }
 	 return transData->transState;
  }


 /*
  * Description :
  * Function responsible for checking is the account is valid.
  */
 EN_serverError_t isValidAccount(ST_cardData_t *cardData){

	 EN_serverError_t accountState;
	 EN_cardError_t temp;
	 
	 int i;

	 do{
		 temp = getCardPan(&cardData);
		
	 }while(temp !=OK);
	 

	 for (i=0;i<2;i++)
	 {
		 if (strcmp(lolo, accountsDataBase[i].primaryAccountNumber) == 0)
	 {	
		 
		 cardIndex = i;
		accountState = OK__;
		break;
	 }
		 else if (strcmp(lolo, stolenCards[i]) == 0)
		 {

			 cardIndex = i;
			 accountState = STOLENCARD;
			 break;
		 }
	 else {
		
		 accountState = ACCOUNT_NOT_FOUND;
	 }
	 }
	
	 return accountState;
 }

 /*
  * Description :
  * Function responsible for checking is the amount is available.
  */
 EN_serverError_t isAmountAvailable(ST_terminalData_t* termData) {

	 EN_serverError_t amountState;
	 EN_cardError_t temp;
	 termData->maxTransAmount = MAX_AMOUNT;
	
	 do {
		 temp = getTransactionAmount(termData);
	 } while (temp != OK_);
	
	 transAmounttemp = termData->transAmount;
	 if (isBelowMaxAmount (termData) == EXCEED_MAX_AMOUNT)
	 {
		 amountState = MaxAmountExceed;
	 }
	 else if(transAmounttemp > accountsDataBase[cardIndex].balance)
	 {
		 amountState = LOW_BALANCE;
	 }
	 else
	 {
		 amountState = OK__;
	 }

	 return amountState;
 }

 /*
  * Description :
  * Function responsible for saving the transaction.
  */

 EN_serverError_t saveTransaction(ST_transaction_t *transData){
	 printf("\t\t\tSaving...\n");
	 EN_serverError_t transactionState;
	 	 if(seqNo < 255)
	 	 {
	 		 transactionsDataBase[seqNo].cardHolderName = transData->cardHolderName;
	 		 transactionsDataBase[seqNo].terminalData = transData->terminalData;
	 		 transactionsDataBase[seqNo].transState = transData->transState;
	 		 transactionsDataBase[seqNo].transactionSequenceNumber= transData->transactionSequenceNumber;
	 		 seqNo++;
	 		 transactionState = OK__;
			 accountsDataBase[cardIndex].balance -= transAmounttemp;
			 printf("\t\t Remaining Balance is %f\n", accountsDataBase[cardIndex].balance);
	 	 }

	 	 else
	 	 {
	 		 transactionState = SAVING_FAILED;
	 	 }
	 return transactionState;
 }

