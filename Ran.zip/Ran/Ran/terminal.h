/******************************************************************************
 *
 * Module: Terminal module
 *
 * File Name: terminal.h
 *
 * Description: This card module take gets the transaction informations
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/

#ifndef TERMINAL_H_
#define TERMINAL_H_
#define _CRT_SECURE_NO_WARNINGS
#include "std_types.h"
#include "Card/card.h"

#define MAX_AMOUNT 2000

typedef struct
{
	float transAmount;
	float maxTransAmount;
	uint8 transactionDate[11];

}ST_terminalData_t;


typedef enum
{
	OK_,WRONG_DATE,EXPIRED_CARD,INVALID_CARD,INVALID_AMOUNT,EXCEED_MAX_AMOUNT,INVALID_MAX_AMOUNT
}EN_terminalError_t;



/*
 * Description :
 * Function responsible for getting the transaction date from the user.
 */
EN_terminalError_t getTransactionDate(ST_terminalData_t *termData);

/*
 * Description :
 * Function responsible for comparing between the expiration date of the card and the transaction date.
 */
EN_terminalError_t isCardExpired(ST_cardData_t *cardData,ST_terminalData_t *termData);

/*
 * Description :
 * Function responsible for checking if the card pan is valid.
 */
EN_terminalError_t isValidCardPan(ST_cardData_t* cardData);

/*
 * Description :
 * Function responsible for getting the transaction amount from the user.
 */
EN_terminalError_t getTransactionAmount(ST_terminalData_t *termData);

/*
 * Description :
 * Function responsible for checking if the transaction amount does not exceed the max transaction amount..
 */
EN_terminalError_t isBelowMaxAmount(ST_terminalData_t *termData);

/*
 * Description :
 * Function responsible for the max transaction amount..
 */
EN_terminalError_t setMaxAmount(ST_terminalData_t *termData);

#endif /* TERMINAL_H_ */
