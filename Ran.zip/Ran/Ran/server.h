/******************************************************************************
 *
 * Module: server module
 *
 * File Name: server.h
 *
 * Description: This card module take gets the transaction informations and check it with the data base stored in the system
 *
 * Author:Raneem Ahmed Samir
 *
 *******************************************************************************/

#ifndef SERVER_H_
#define SERVER_H_

#include "Terminal/terminal.h"
#include "Card/card.h"
#define _CRT_SECURE_NO_WARNINGS

typedef enum{

	APPROVED,DECLINED_INSUFFECIENT_FUND,DECLINED_STOLEN_CARD,INTERNAL_SERVER_ERROR,EXPIREDCARD,MaxAmouExceed

}EN_transState_t;

typedef enum{

	OK__,SAVING_FAILED,TRANSACTION_NOT_FOUND,ACCOUNT_NOT_FOUND,LOW_BALANCE,MaxAmountExceed,STOLENCARD

}EN_serverError_t;


typedef struct ST_transaction_t{

	ST_cardData_t cardHolderName;
	ST_terminalData_t terminalData;
	EN_transState_t transState;
	uint32 transactionSequenceNumber;

}ST_transaction_t;


typedef struct ST_accountDB_t
{
    float balance;
    uint8 primaryAccountNumber[20];
} ST_accountDB_t;


/*
 * Description :
 * Function responsible for getting the transaction date from the user.
 */
EN_transState_t recieveTransactionData(ST_transaction_t *transData);

/*
 * Description :
 * Function responsible for checking is the account is valid.
 */
EN_serverError_t isValidAccount(ST_cardData_t *cardData);

/*
 * Description :
 * Function responsible for checking is the amount is available.
 */
EN_serverError_t isAmountAvailable(ST_terminalData_t *termData);

/*
 * Description :
 * Function responsible for saving the transaction.
 */
EN_serverError_t saveTransaction(ST_transaction_t *transData);

/*
 * Description :
 * Function responsible for getting the transaction sequence number.
 */
EN_serverError_t getTransaction(uint32 transactionSequenceNumber,ST_transaction_t *transData);

void writteDataBase(void);

#endif /* SERVER_H_ */
