/******************************************************************************
 *
 * Module: Card module
 *
 * File Name: Card.c
 *
 * Description: This card module take gets the card informations
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/

#include "Card/card.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
extern uint8 lolo[20];
/*
 * Description :
 * Function responsible for getting the card holder name from the user.
 */
EN_cardError_t getCardHolderName(ST_cardData_t *cardData){

	EN_cardError_t cardHolderNameState= OK;

	printf("Please Enter Your Name: 	(20-24 letters and numbers)\n");
	gets(cardData->cardHolderName);
	if((strlen(cardData->cardHolderName) <20) || (strlen(cardData->cardHolderName) > 24 ))
	{
		cardHolderNameState = WRONG_NAME;
	}
	

	return cardHolderNameState;
}

/*
 * Description :
 * Function responsible for getting the card expiry date from the user.
 */
EN_cardError_t getCardExpiryDate(ST_cardData_t *cardData){

	EN_cardError_t cardExpiryDateState= OK;
	printf("Please Enter Your Card Expiry Date: 	(MM/YY)\n");
	scanf("%s",cardData->cardExpirationDate);
	uint8 month[2];//initialize a variable array of 2 elements
	uint8 MM;//initialize day
	uint8 year[2];
	uint8 YY;
	month[0] = cardData->cardExpirationDate[0];
	month[1] = cardData->cardExpirationDate[1];
	year[0]= cardData->cardExpirationDate[3];
	year[1] = cardData->cardExpirationDate[4];
	MM = atoi(month);
	YY = atoi(year);

	/*
	 *1- Check if the date is equal to null
	 *2- Check if the date is not equal to 5
	 *3- Check if the date is in wrong format
	 */
	

	if (strlen(cardData->cardExpirationDate) != 5 || (MM > 12 || YY == 0 ))
	{
		cardExpiryDateState = WRONG_EXP_DATE;
	}
	
	return cardExpiryDateState;
}


/*
 * Description :
 * Function responsible for getting the card pan from the user.
 */
EN_cardError_t getCardPan(ST_cardData_t *cardData){
	EN_cardError_t cardPanState;

	printf("Please Enter Your Primary Account Number: (16-19 letters or numbers)\n");
	scanf("%s", cardData->primaryAccountName);
	
	/*
		 *1- Check if the pan is equal to null
		 *2- Check if the pan is smaller than 16
		 *3- Check if the pan is larger than 19
		 */
	if((cardData->primaryAccountName == '\0') || (strlen(cardData->primaryAccountName) < 16) || (strlen(cardData->primaryAccountName) > 19) )
	{
		cardPanState = WRONG_PAN;
	}
	else
	{
		cardPanState = OK;
		strcpy(lolo, cardData->primaryAccountName);
	}
	return cardPanState;
}
