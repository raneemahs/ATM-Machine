/******************************************************************************
 *
 * Module: server module
 *
 * File Name: server.c
 *
 * Description: This card module take gets the transaction informations and check it with the data base stored in the system
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/

#include"app.h"
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


void main (void)
{
	uint8 exit=1;
	
	while(1) {
		
		if (exit==0)
		{
			return ;
		}
		else
		{
			application();
			printf("Press 0 TO Exit\n");
			scanf("%d", &exit);
		}
		
	} 
	
}
