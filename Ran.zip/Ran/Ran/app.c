/******************************************************************************
 *
 * Module: server module
 *
 * File Name: server.c
 *
 * Description: This card module take gets the transaction informations and check it with the data base stored in the system
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/
#include "Server/server.h"
#include "Terminal/terminal.h"
#define _CRT_SECURE_NO_WARNINGS



void application (void){
	printf("------------------------------------------------------------------\n");
	printf("\t \tWelcome To Our Payment Application\n");
	printf("------------------------------------------------------------------\n");

	ST_transaction_t transData;
	switch (recieveTransactionData(&transData)) {
	case APPROVED: printf("\tYour Transaction is Successful\n"); 
	break;
	case DECLINED_INSUFFECIENT_FUND: printf("You Don't Have Enough Balance\n");
	break;
	case MaxAmouExceed: printf("Exceeded The Maximum Amount \n");
	break;
	case DECLINED_STOLEN_CARD: printf("Reporting A Stolen Card Case\n");
	break;
	case INTERNAL_SERVER_ERROR:printf("Transactions Is Not Successful\n");
	break;
	case EXPIREDCARD:printf("Your Card Is Expired\n");
	break;

	}
	
}

