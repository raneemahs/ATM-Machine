/******************************************************************************
 *
 * Module: server module
 *
 * File Name: server.c
 *
 * Description: This card module take gets the transaction informations and check it with the data base stored in the system
 *
 * Author: Raneem Ahmed Samir
 *
 *******************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#ifndef APP_H_
#define APP_H_


#include "std_types.h"

void application(void);

#endif /* APP_H_ */
